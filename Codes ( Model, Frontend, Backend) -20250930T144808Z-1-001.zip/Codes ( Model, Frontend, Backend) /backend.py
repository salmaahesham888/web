from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import joblib
import shap

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for now, you can restrict later
    allow_methods=["*"],  # Allow all methods (POST, GET, etc.)
    allow_headers=["*"],  # Allow all headers
)

# Load your model and columns here (example)
try:
    model = joblib.load("attrition_model_xgboost_test.pkl")
    model_columns = joblib.load("model_columns_test.pkl")
except FileNotFoundError:
    print("Model or columns file not found.")
    exit()

explainer = shap.Explainer(model)

# Recommendation dictionary
recommendations = {
    "MonthlyIncome": "Increase salary to align with market trends to improve retention.",
    "StockOptionLevel": "Provide stock options to retain key employees and motivate high performers.",
    "TotalWorkingYears": "Offer career development opportunities to retain younger employees.",
    "JobRole": "Align job roles with employee strengths and provide clear career growth paths.",
    "JobLevel": "Offer promotions based on performance and provide leadership training.",
    "YearsAtCompany": "Offer new challenges and career growth opportunities to long-tenured employees.",
    "Age": "Offer stability for older employees, and career development for younger employees.",
    "OverTime": "Monitor work hours to prevent burnout and maintain work-life balance.",
    "DailyRate": "Ensure fair compensation for employees with low daily rates.",
    "YearsSinceLastPromotion": "Regularly evaluate employees for promotions to keep them engaged.",
    "YearsWithCurrManager": "Encourage communication between employees and managers to maintain a strong relationship.",
    "Work_accident": "Ensure workplace safety and offer support to employees recovering from accidents.",
    "Working with current manager": "Provide manager training and foster a positive work environment.",
    "PercentSalaryHike": "Offer salary hikes in line with market standards to keep employees satisfied.",
    "PerformanceRating": "Provide constructive feedback and training for employees with low ratings.",
    "RelationshipSatisfaction": "Promote team-building activities and resolve conflicts quickly.",
    "StandardHours": "Recognize hard work and offer appropriate incentives to employees working standard hours.",
    "TrainingTimesLastYear": "Invest in ongoing training programs to enhance employees' skills and career development.",
    "WorkLifeBalance": "Encourage flexible work hours and remote work options to improve work-life balance."
}

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    df = pd.read_csv(file.file)

    if "EmployeeNumber" not in df.columns:
        return {"error": "CSV must contain 'EmployeeNumber' column"}
    if "EmployeeName" not in df.columns: # NEW: Check for EmployeeName
        return {"error": "CSV must contain 'EmployeeName' column"}

    employee_numbers = df["EmployeeNumber"].tolist()
    employee_names = df["EmployeeName"].tolist() # NEW: Get employee names
    job_roles = df["JobRole"].tolist()

    df_processed = pd.get_dummies(df, drop_first=True)
    df_processed = df_processed.reindex(columns=model_columns, fill_value=0)

    probabilities = model.predict_proba(df_processed)[:, 1]

    high_risk_threshold = 0.7
    medium_risk_threshold = 0.3

    labels = []
    for prob in probabilities:
        if prob >= high_risk_threshold:
            labels.append("High")
        elif prob >= medium_risk_threshold:
            labels.append("Medium")
        else:
            labels.append("Low")

    shap_values = explainer(df_processed)

    top_features = []
    recommendations_list = []

    for i, shap_row in enumerate(shap_values.values):
        contrib = pd.Series(shap_row, index=df_processed.columns)
        top_feature_full_name = contrib.abs().idxmax()

        if "_" in top_feature_full_name:
            feature_only = top_feature_full_name.split("_", 1)[0]
        else:
            feature_only = top_feature_full_name

        top_features.append(feature_only)
        recommendations_list.append(recommendations.get(feature_only, "No specific recommendation available"))

    results = []
    # NEW: Include employee_names in the zip and the result list
    for emp_num, emp_name, role, risk_label, reason, rec in zip(employee_numbers, employee_names, job_roles, labels, top_features, recommendations_list):
        results.append([emp_num, emp_name, role, risk_label, reason, rec])

    # NEW: Add "Employee Name" to headers
    return {"headers": ["EmployeeNumber", "Employee Name", "Job Role", "Risk Level", "Top Contributing Feature", "Recommendation"], "rows": results}