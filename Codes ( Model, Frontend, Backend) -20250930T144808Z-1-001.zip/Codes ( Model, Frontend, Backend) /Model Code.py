import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib
import shap
from xgboost import XGBClassifier

# Load the dataset
data = pd.read_csv(r"D:\FCAI\GP\AEA_Cleaned.csv")

# Define features
features = [
    "MonthlyIncome", "StockOptionLevel", "TotalWorkingYears", "JobRole", "JobLevel",
    "YearsAtCompany", "Age", "OverTime", "DailyRate", "YearsSinceLastPromotion"
]

# Prepare the data
model_data = data[features + ["Attrition"]].copy()
model_data["Attrition"] = model_data["Attrition"].apply(lambda x: 1 if x == "Yes" else 0)
model_data = pd.get_dummies(model_data, drop_first=True)

# Split data into train and test sets
X = model_data.drop("Attrition", axis=1)
y = model_data["Attrition"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = XGBClassifier(
    n_estimators=200,
    max_depth=10,
    learning_rate=0.1,
    scale_pos_weight=(len(y_train) - sum(y_train)) / sum(y_train),
    random_state=42,
    use_label_encoder=False,
    eval_metric='logloss'
)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))

print("\n--- Classification Report (Test Set) ---")
print(classification_report(y_test, y_pred, target_names=["Stayed", "Left"]))

# Saving the model
joblib.dump(model, "attrition_model_xgboost_test.pkl", compress=3)
print("Model saved as 'attrition_model_xgboost_test.pkl'")

# Save the model columns
model_columns = X_train.columns
joblib.dump(model_columns, 'model_columns_test.pkl')
print("Model columns saved to model_columns_test.pkl")

# SHAP Values
explainer = shap.Explainer(model)
shap_values = explainer(X_train)

# --- Top Contributing Feature ---
def get_top_contributing_feature(shap_values_row):
    contributions = pd.Series(shap_values_row, index=X_train.columns)
    top_feature = contributions.idxmax()  # Get the feature with the highest SHAP value
    return top_feature

# Get the top contributing feature for each employee in the test set
top_feature_list = []
for i in range(len(X_test)):
    top_feature = get_top_contributing_feature(shap_values[i].values)
    top_feature_list.append(top_feature)  # Store the top feature for each employee

# Prepare the result dataframe
result_df = X_test.copy()
result_df['Attrition_Prediction'] = y_pred
result_df['Top_Contributing_Feature'] = top_feature_list

# Save the result to a CSV
result_df[['EmployeeNumber', 'Attrition_Prediction', 'Top_Contributing_Feature']].to_csv("attrition_predictions_with_top_feature_test.csv", index=False)

# Display the results
print(result_df[['EmployeeNumber', 'Attrition_Prediction', 'Top_Contributing_Feature']].head())
